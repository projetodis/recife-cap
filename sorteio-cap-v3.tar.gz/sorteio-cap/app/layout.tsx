import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'NatalCap — Sistema de Capitalização',
  description: 'Gestão de cartelas, distribuidores, PDVs e sorteios',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  )
}
