import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export default async function DistribuidorDashboard() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single()

  const { data: dist } = await supabase
    .from('distribuidores')
    .select('*')
    .eq('user_id', user.id)
    .single()

  const { data: pdvs } = await supabase
    .from('pontos_de_venda')
    .select('*')
    .eq('distribuidor_id', dist?.id)

  const { data: cartelas } = await supabase
    .from('cartelas')
    .select('status')
    .eq('distribuidor_id', dist?.id)

  const { data: comissoes } = await supabase
    .from('comissoes')
    .select('valor, status')
    .eq('beneficiario_id', user.id)

  const totalPDVs = pdvs?.length ?? 0
  const pdvsAtivos = pdvs?.filter(p => p.status === 'ativo').length ?? 0
  const cartelasEmEstoque = cartelas?.filter(c =>
    c.status === 'em_estoque_distribuidor' || c.status === 'em_estoque_pdv'
  ).length ?? 0
  const cartelasVendidas = cartelas?.filter(c => c.status === 'paga').length ?? 0
  const comissaoPendente = comissoes
    ?.filter(c => c.status === 'pendente')
    .reduce((acc, c) => acc + Number(c.valor), 0) ?? 0

  const statusPixMap: Record<string, { label: string; color: string }> = {
    pendente:             { label: 'Não cadastrada', color: 'text-gray-500 bg-gray-100' },
    aguardando_validacao: { label: 'Aguardando validação', color: 'text-amber-700 bg-amber-50' },
    validado:             { label: 'Validada', color: 'text-emerald-700 bg-emerald-50' },
    rejeitado:            { label: 'Rejeitada', color: 'text-red-700 bg-red-50' },
  }
  const statusPix = statusPixMap[profile?.status_pix ?? 'pendente'] ?? statusPixMap['pendente']

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">Painel do distribuidor</h1>
        <p className="text-sm text-gray-500 mt-1">Bem-vindo, {profile?.nome}</p>
      </div>

      {/* Info do perfil */}
      <div className="bg-white rounded-xl border border-gray-200 p-5 mb-6 flex flex-wrap gap-6 items-center">
        <div>
          <p className="text-xs text-gray-400 mb-0.5">CPF</p>
          <p className="text-sm font-medium text-gray-900">{profile?.cpf ?? '—'}</p>
        </div>
        <div>
          <p className="text-xs text-gray-400 mb-0.5">Chave PIX</p>
          <p className="text-sm font-medium text-gray-900">{profile?.chave_pix ?? '—'}</p>
        </div>
        <div>
          <p className="text-xs text-gray-400 mb-0.5">Nível</p>
          <p className="text-sm font-medium text-gray-900">nv:{dist?.nivel ?? 1}</p>
        </div>
        <div className="ml-auto">
          <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${statusPix.color}`}>
            {statusPix.label}
          </span>
        </div>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Meus PDVs', value: totalPDVs, sub: `${pdvsAtivos} ativos` },
          { label: 'Cartelas em estoque', value: cartelasEmEstoque.toLocaleString('pt-BR'), sub: 'na cadeia' },
          { label: 'Cartelas vendidas', value: cartelasVendidas.toLocaleString('pt-BR'), sub: 'confirmadas' },
          { label: 'Comissão a receber', value: comissaoPendente.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }), sub: 'pendente' },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-xl border border-gray-200 p-5">
            <p className="text-xs text-gray-500 mb-2">{c.label}</p>
            <p className="text-2xl font-semibold text-gray-900 mb-1">{c.value}</p>
            <p className="text-xs text-gray-400">{c.sub}</p>
          </div>
        ))}
      </div>

      {/* Lista de PDVs */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-sm font-medium text-gray-900">Meus PDVs</h2>
          <a href="/distribuidor/pdvs/novo" className="text-xs text-emerald-600 hover:text-emerald-700 font-medium">
            + Cadastrar PDV
          </a>
        </div>
        {pdvs && pdvs.length > 0 ? (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="text-left text-xs text-gray-400 font-medium px-6 py-3">Nome</th>
                <th className="text-left text-xs text-gray-400 font-medium px-6 py-3">Responsável</th>
                <th className="text-left text-xs text-gray-400 font-medium px-6 py-3">Cidade</th>
                <th className="text-left text-xs text-gray-400 font-medium px-6 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {pdvs.map((pdv, i) => (
                <tr key={pdv.id} className={i % 2 === 0 ? '' : 'bg-gray-50'}>
                  <td className="px-6 py-3 font-medium text-gray-900">{pdv.nome}</td>
                  <td className="px-6 py-3 text-gray-600">{pdv.responsavel_nome}</td>
                  <td className="px-6 py-3 text-gray-600">{pdv.cidade ?? '—'}</td>
                  <td className="px-6 py-3">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      pdv.status === 'ativo' ? 'bg-emerald-50 text-emerald-700' :
                      pdv.status === 'sem_estoque' ? 'bg-amber-50 text-amber-700' :
                      'bg-gray-100 text-gray-500'
                    }`}>
                      {pdv.status === 'ativo' ? 'Ativo' :
                       pdv.status === 'sem_estoque' ? 'Sem estoque' : 'Inativo'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="px-6 py-12 text-center">
            <p className="text-sm text-gray-400">Nenhum PDV cadastrado ainda.</p>
            <a href="/distribuidor/pdvs/novo" className="text-sm text-emerald-600 font-medium mt-2 inline-block">
              Cadastrar primeiro PDV →
            </a>
          </div>
        )}
      </div>
    </div>
  )
}
