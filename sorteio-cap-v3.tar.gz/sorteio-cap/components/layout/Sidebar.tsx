'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import type { UserRole } from '@/types'

interface NavItem {
  label: string
  href: string
  icon: React.ReactNode
}

const NAV_ITEMS: Record<UserRole, NavItem[]> = {
  admin: [
    { label: 'Dashboard',      href: '/admin/dashboard',      icon: <IconHome /> },
    { label: 'Distribuidores', href: '/admin/distribuidores',  icon: <IconUsers /> },
    { label: 'PDVs',           href: '/admin/pdvs',            icon: <IconStore /> },
    { label: 'Edições',        href: '/admin/edicoes',         icon: <IconCalendar /> },
    { label: 'Cartelas',       href: '/admin/cartelas',        icon: <IconTicket /> },
    { label: 'Sorteios',       href: '/admin/sorteios',        icon: <IconTrophy /> },
    { label: 'Relatórios',     href: '/admin/relatorios',      icon: <IconChart /> },
  ],
  distribuidor: [
    { label: 'Dashboard',   href: '/distribuidor/dashboard',  icon: <IconHome /> },
    { label: 'Meus PDVs',   href: '/distribuidor/pdvs',       icon: <IconStore /> },
    { label: 'Cartelas',    href: '/distribuidor/cartelas',   icon: <IconTicket /> },
    { label: 'Relatórios',  href: '/distribuidor/relatorios', icon: <IconChart /> },
    { label: 'Perfil',      href: '/distribuidor/perfil',     icon: <IconUser /> },
  ],
  pdv: [
    { label: 'Dashboard',  href: '/pdv/dashboard',  icon: <IconHome /> },
    { label: 'Nova venda', href: '/pdv/venda',      icon: <IconPlus /> },
    { label: 'Cartelas',   href: '/pdv/cartelas',   icon: <IconTicket /> },
    { label: 'Caixa',      href: '/pdv/caixa',      icon: <IconCash /> },
  ],
  cliente: [
    { label: 'Minhas cartelas', href: '/cliente/dashboard', icon: <IconTicket /> },
    { label: 'Sorteios',        href: '/cliente/sorteios',  icon: <IconTrophy /> },
    { label: 'Perfil',          href: '/cliente/perfil',    icon: <IconUser /> },
  ],
}

interface SidebarProps {
  role: UserRole
  nome: string
  nivel?: number
}

export function Sidebar({ role, nome, nivel }: SidebarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  const navItems = NAV_ITEMS[role]

  const roleLabels: Record<UserRole, string> = {
    admin: 'Administrador',
    distribuidor: `Distribuidor${nivel ? ` nv:${nivel}` : ''}`,
    pdv: 'Ponto de Venda',
    cliente: 'Cliente',
  }

  return (
    <aside className="fixed left-0 top-0 h-full w-52 bg-slate-900 flex flex-col z-40">
      {/* Logo */}
      <div className="px-4 py-5 border-b border-slate-700">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center flex-shrink-0">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
            </svg>
          </div>
          <div>
            <p className="text-white text-sm font-medium leading-none">NatalCap</p>
            <p className="text-slate-400 text-xs mt-0.5">{roleLabels[role]}</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map(item => {
          const active = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                active
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span className="w-4 h-4 flex-shrink-0">{item.icon}</span>
              {item.label}
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="px-4 py-4 border-t border-slate-700">
        <p className="text-slate-400 text-xs truncate mb-2">{nome}</p>
        <button
          onClick={handleLogout}
          className="text-slate-400 hover:text-white text-xs transition-colors"
        >
          Sair
        </button>
      </div>
    </aside>
  )
}

// Icons inline para não precisar de dependência extra
function IconHome() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
}
function IconUsers() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
}
function IconStore() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M3 9l1-6h16l1 6"/><path d="M3 9a2 2 0 004 0 2 2 0 004 0 2 2 0 004 0 2 2 0 004 0"/><path d="M5 9v12h14V9"/></svg>
}
function IconCalendar() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
}
function IconTicket() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M2 9a3 3 0 010-6h20a3 3 0 010 6"/><path d="M2 15a3 3 0 000 6h20a3 3 0 000-6"/><path d="M6 9v6M10 9v6M14 9v6M18 9v6"/></svg>
}
function IconTrophy() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><polyline points="8 21 12 17 16 21"/><path d="M4 7h16"/><path d="M4 7a8 8 0 008 8 8 8 0 008-8"/><path d="M4 7H2"/><path d="M22 7h-2"/></svg>
}
function IconChart() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
}
function IconUser() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
}
function IconPlus() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
}
function IconCash() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 12h.01M18 12h.01"/></svg>
}
